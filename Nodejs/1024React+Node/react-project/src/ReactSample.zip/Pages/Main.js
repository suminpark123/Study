import React from 'react'
import Photo from '../Layout/Photo'

const Main = () => {

    return (
        <div>
            <Photo />
        </div>
    )
}

export default Main